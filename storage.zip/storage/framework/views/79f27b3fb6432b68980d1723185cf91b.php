<?php $__env->startSection('content'); ?>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <div class="col-md-12 grid-margin stretch-card">
        <div class="card">
            <?php if(session('status')): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(session('status')); ?>

                </div>
            <?php endif; ?>
            <div class="card-body">
                <form class="forms-sample">
                    <div class="row">
                        <div class="form-group col-md-4">
                            <label for="join">Start Date</label>
                            <input type="datetime-local" class="form-control" name="start_date">
                        </div>
                        <div class="form-group col-md-4">
                            <label for="join">End Date</label>
                            <input input type="datetime-local" class="form-control" name="end_date">
                        </div>
                        <div class="form-group col-md-4">
                            <label for="duration">Gender</label>
                            
                            <select class="form-control" name="duration" id="duration">
                                <option value="1">All</option>
                                <option value="2">Partial</option>
                                <option value="3" id="completed">Completed</option>
                            </select>
                            
                        </div>
                        
                    </div>
                    <div class="row">
                        <div class="col-md-8"></div>
                        <div class="col-md-4">
                            <button class="btn btn-sm btn-success">Submit</button>
                            <button class="btn btn-sm btn-danger">Clear Filters</button>
                            <button class="btn btn-sm btn-info">Download CSV</button>
                        </div>
                    </div>
                    <div class="row">
                        <div class="com-md-12">
                            <table class="table table-hover">
                                <thead>
                                    <tr>
                                        <th>Id</th>
                                        <th>Created At</th>
                                        <th>Ended At</th>
                                        <th>Name</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $ssb_leads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ssb_lead): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($ssb_lead->id); ?></td>
                                            <td><?php echo e($ssb_lead->created_at); ?></td>
                                            <td class="text-danger"><?php echo e($ssb_lead->updated_at); ?></td>
                                            <td><?php echo e($ssb_lead->case_description); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script>
        flatpickr("input[type=datetime-local]");
    </script>
<?php $__env->stopSection(); ?>


    

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/salman/Desktop/practicephp/laravel/pcpcheckerbyzain/PCP-Checker/resources/views/home.blade.php ENDPATH**/ ?>